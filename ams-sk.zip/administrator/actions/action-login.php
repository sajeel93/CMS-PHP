<?php
require "../config/configuration.php";

$username = htmlspecialchars(trim($_POST["username"]));
$password = htmlspecialchars(trim($_POST["password"]));

$isCredentialsTrue = loginUser($username, $password);

if($isCredentialsTrue)
{
    $data = $isCredentialsTrue;
    setUserSession($data);

    // Set the redirect url after successful login
    $redirect_url = ADMIN_PAGES . 'dashboard/';
}else {
    $_SESSION['response'] = 'invalid';

    $redirect_url = SITEURL_ADMIN . 'index.php';
}

redirect($redirect_url);
exit;