<?php
require "../config/configuration.php";

// Logout the user
logout();
header("Location: " . SITEURL_ADMIN . 'index.php');