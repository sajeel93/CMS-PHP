<?php
// Encrypt a string (for password)
function encryptThis($string)
{
    return md5($string);
}

// SESSION Set for response
function makeSessionResponse($type, $title, $desc)
{
    $_SESSION['response']['type'] = $type;
    $_SESSION['response']['title'] = $title;
    $_SESSION['response']['desc'] = $desc;
}

function getPagination($pageNo, $perPage, $table)
{
    global $pdo;

    $row_count = $pdo->query("SELECT count(*) FROM $table")->fetchColumn();

    $page_count = 0;
    if (0 === $row_count) {
        // maybe show some error since there is nothing in your table
    } else {
        // determine page_count
        $page_count = (int)ceil($row_count / $perPage);
        // double check that request page is in range
        if ($pageNo > $page_count) {
            // error to user, maybe set page to 1
            $page = 1;
        }
    }

    if ($page_count == 1) {
        return false;
    }

    $str = '';

    $str .= '<ul class="pagination pagination-sm" style="margin: 0;">';
    for ($i = 1; $i <= $page_count; $i++) {
        $active = '';
        if ($i === $pageNo) {
            $active = 'active';
        }
        $str .= '<li class="' . $active . '">';
        $str .= '<a href="?page=' . $i . '&per_page=' . $perPage . '">';
        $str .= $i;
        $str .= '</a>';
        $str .= '</li>';
    }
    $str .= '</ul>';

    return $str;
}

function getOffset($page, $perPage)
{
    return $offset = ($page - 1) * $perPage;
}

// Check User login
function loginUser($username, $password)
{
    global $pdo;

    $password = encryptThis($password);

    $sql = "SELECT * FROM admin_users WHERE admin_username = ? AND admin_password = ? LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array($username, $password));
    $data = $stmt->fetch();

    if (!$data) {
        return false;
    }

    updateLoginTime($data['admin_id']);

    return $data;
}

// Update login Time
function updateLoginTime($id)
{
    global $pdo;

    $now = date("Y-m-d H:i:s");
    $sql = "UPDATE admin_users SET admin_login_time=? WHERE admin_id=$id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array($now));
}

function setUserSession($data)
{
    $_SESSION['admin_loginned'] = true;
    $_SESSION['admin_user_id'] = $data['admin_id'];
    $_SESSION['admin_username'] = $data['admin_username'];
    $_SESSION['admin_name'] = $data['admin_first_name'] . " " . $data['admin_last_name'];
}

function logout()
{
    session_destroy();
}

function isLogin()
{
    if (isset($_SESSION['admin_loginned']) && $_SESSION['admin_loginned']) {
        return true;
    }

    return false;
}

function redirect($page)
{
    header('Location: ' . $page);
}

function uploadFile($files, $inputValue, $dir, $oldFile = false)
{
    if ($files[$inputValue]['name'] != "") {
        if ($oldFile) {
            // Delete previous file
            $oldFile && unlink($dir . $oldFile);
        }

        $name = "i_" . time() . $_FILES[$inputValue]['name'];
        $fileDest = $dir . $name;
        move_uploaded_file($_FILES[$inputValue]['tmp_name'], $fileDest);
        chmod($fileDest, 0777);

        return $name;
    }

    return false;
}

function getAllEmployees($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM employees";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM employees LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getEmployee($id)
{
    global $pdo;

    $stmt = $pdo->prepare('SELECT * FROM employees WHERE employee_id=? LIMIT 1');
    $stmt->execute(array($id));

    $data = $stmt->fetch();

    if (!$data) {
        $data = false;
    }

    return $data;
}

function addEmployee($data)
{
    global $pdo;

    if (isset($data["employee_active"])) {
        $data['employee_active'] = 1;
    } else {
        $data['employee_active'] = 0;
    }


    $data['now'] = date("Y-m-d H:i:s");

    $fields = "SET email=?,avatar=?, active=?, first_name=?, last_name=?, gender=?, phone_no=?";

    try {
        $stmt = $pdo->prepare("INSERT INTO users $fields");
        $stmt->execute(
            array(
                $data['email_address'],
                $data['employee_image'],
                $data['employee_active'],
                $data['first_name'],
                $data['last_name'],
                $data['gender'],
                $data['number'],
            ));
    } catch (PDOException $Exception) {
        return false;
    }

    return true;
}

function modifyEmployee($data, $id)
{
    global $pdo;

    if (isset($data["user_active"])) {
        $data['user_active'] = 1;
    } else {
        $data['user_active'] = 0;
    }


    $fields = "SET email=?,avatar=?, active=?, first_name=?, last_name=?, gender=?, phone_no=?";

    try {
        $stmt = $pdo->prepare("UPDATE users $fields  WHERE employee_id=$id");
        $stmt->execute(
            array(
                $data['email_address'],
                $data['employee_image'],
                $data['employee_active'],
                $data['first_name'],
                $data['last_name'],
                $data['gender'],
                $data['number'],
            ));
    } catch (PDOException $Exception) {
        return false;
    }
    return true;
}

function deleteQuery($id, $table, $column)
{
    global $pdo;
    try {
        $stmt = $pdo->prepare("DELETE FROM $table WHERE $column=? LIMIT 1");
        $stmt->execute(array($id));
    } catch (PDOException $Exception) {
        return false;
    }

    return true;
}

function deleteQueryForIds($ids, $table, $column)
{
    global $pdo;
    try {
        $stmt = $pdo->prepare("DELETE FROM $table WHERE $column IN ($ids)");
        $stmt->execute(array($ids));
    } catch (PDOException $Exception) {
        return false;
    }

    return true;
}

function getTopLastLoginedUsers()
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM users ORDER BY last_login_date DESC LIMIT 10");
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getAllAdminUsers($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM admin_users";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM admin_users LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getAllComplaints($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM complaints";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM complaints LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getUnreadComplaints($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM complaints WHERE status=0";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM complaints WHERE status=0 LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getReadComplaints($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM complaints WHERE status=1";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM complaints WHERE status=1 LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function updateReadComplaint($value, $id)
{
    global $pdo;

    $fields = "SET status=$value";

    try {
        $stmt = $pdo->prepare("UPDATE complaints $fields WHERE complaint_id=?");
        $stmt->execute(array($id));
    } catch (PDOException $Exception) {
        return false;
    }
    return true;
}

function getTotalUnreadComplaints()
{
    global $pdo;

    $sql = "SELECT count(*) as total FROM complaints 
            WHERE status=0";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = $stmt->fetch();

    if (!$data) {
        $data = '0';
    }

    return $data['total'];
}

function getSetting($id = 1)
{
    global $pdo;

    $stmt = $pdo->prepare('SELECT * FROM site_custom_settings WHERE setting_id=? LIMIT 1');
    $stmt->execute(array($id));

    $data = $stmt->fetch();

    if (!$data) {
        $data = false;
    }

    return $data;
}

function modifySetting($data, $id = 1)
{
    global $pdo;

    if (isset($data["site_live"])) {
        $data['site_live'] = 0;
    } else {
        $data['site_live'] = 1;
    }

    $fields = "SET site_live=?, logoimage=?, styles=?, sitename=?, phonenum=?, pinterest=?, linkedin=?";

    try {
        $stmt = $pdo->prepare("UPDATE site_custom_settings $fields WHERE setting_id=$id");
        $stmt->execute(
            array(
                $data['site_live'],
                $data['logoimage'],
                $data['styles'],
                $data['sitename'],
                $data['phonenum'],
                $data['pinterest'],
                $data['linkedin'],
            ));
    } catch (PDOException $Exception) {
        return false;
    }
    return true;
}

function getAllCategories($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM categories";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM categories LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getCategory($id)
{
    global $pdo;

    $stmt = $pdo->prepare('SELECT * FROM categories WHERE c_id=? LIMIT 1');
    $stmt->execute(array($id));

    $data = $stmt->fetch();

    if (!$data) {
        $data = false;
    }

    return $data;
}

function addCategory($data)
{
    global $pdo;

    $data['c_name'] ? '' : $data['c_name'] = NULL;
    $data['c_desc'] ? '' : $data['c_desc'] = NULL;
    $data['cat_image'] ? '' : $data['cat_image'] = NULL;
    $data['c_order'] ? '' : $data['c_order'] = 0;
    $data['parent_id'] ? '' : $data['parent_id'] = 0;

    if (isset($data["category_active"])) {
        $data['category_active'] = 1;
    } else {
        $data['category_active'] = 0;
    }

    $data['now'] = date("Y-m-d H:i:s");

    $fields = "SET c_name=?, c_desc=?, c_icon=?, active=?, c_order=?, parent_id=?, created_at=?";

    try {
        $stmt = $pdo->prepare("INSERT INTO categories $fields");
        $stmt->execute(
            array(
                $data['c_name'],
                $data['c_desc'],
                $data['cat_image'],
                $data['category_active'],
                $data['c_order'],
                $data['parent_id'],
                $data['now']
            ));
    } catch (PDOException $Exception) {
        return false;
    }

    return true;
}

function modifyCategory($data, $id)
{
    global $pdo;

    $data['c_name'] ? '' : $data['c_name'] = NULL;
    $data['c_desc'] ? '' : $data['c_desc'] = NULL;
    $data['cat_image'] ? '' : $data['cat_image'] = NULL;
    $data['c_order'] ? '' : $data['c_order'] = 0;
    $data['parent_id'] ? '' : $data['parent_id'] = 0;

    if (isset($data["category_active"])) {
        $data['category_active'] = 1;
    } else {
        $data['category_active'] = 0;
    }

    $data['now'] = date("Y-m-d H:i:s");

    $fields = "SET c_name=?, c_desc=?, c_icon=?, active=?, c_order=?, parent_id=?, last_updated=?";

    try {
        $stmt = $pdo->prepare("UPDATE categories $fields  WHERE c_id=$id");
        $stmt->execute(
            array(
                $data['c_name'],
                $data['c_desc'],
                $data['cat_image'],
                $data['category_active'],
                $data['c_order'],
                $data['parent_id'],
                $data['now']
            ));
    } catch (PDOException $Exception) {
        return false;
    }
    return true;
}

function getAllGroups($page, $perPage)
{
    global $pdo;

    if ($perPage == 'all') {
        $sql = "SELECT * FROM groups";
    } else {
        $offset = getOffset($page, $perPage);
        $sql = "SELECT * FROM groups LIMIT $offset, " . $perPage;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function getGroup($id)
{
    global $pdo;

    $stmt = $pdo->prepare('SELECT * FROM groups WHERE g_id=? LIMIT 1');
    $stmt->execute(array($id));

    $data = $stmt->fetch();

    if (!$data) {
        return false;
    }


    $data['business_hours'] = getBusinessHours($data['g_id']);

    return $data;
}

function addGroup($data)
{
    global $pdo;

    $data['g_title'] ? '' : $data['g_title'] = NULL;
    $data['cat_id'] ? '' : $data['cat_id'] = NULL;
    $data['group_image'] ? '' : $data['group_image'] = NULL;
    $data['g_payment_methods'] ? '' : $data['g_payment_methods'] = NULL;
    $data['address'] ? '' : $data['address'] = NULL;
    $data['g_desc'] ? '' : $data['g_desc'] = NULL;
    $data['g_products_and_services'] ? '' : $data['g_products_and_services'] = NULL;
    $data['g_specialities'] ? '' : $data['g_specialities'] = NULL;
    $data['g_languages'] ? '' : $data['g_languages'] = NULL;
    $data['contact_number'] ? '' : $data['contact_number'] = NULL;

    if (isset($data["group_active"])) {
        $data['group_active'] = 1;
    } else {
        $data['group_active'] = 0;
    }

    $data['now'] = date("Y-m-d H:i:s");

    $fields = "SET g_title=?, cat_id=?, g_icon=?, active=?, g_payment_methods=?, address=?, g_desc=?, g_products_and_services=?, g_specialities=?, g_languages=?, contact_number=?, created_at=?";

    try {
        $stmt = $pdo->prepare("INSERT INTO groups $fields");
        $stmt->execute(
            array(
                $data['g_title'],
                $data['cat_id'],
                $data['group_image'],
                $data['group_active'],
                $data['g_payment_methods'],
                $data['address'],
                $data['g_desc'],
                $data['g_products_and_services'],
                $data['g_specialities'],
                $data['g_languages'],
                $data['contact_number'],
                $data['now']
            ));

        $group_id = $pdo->lastInsertId();
        $sql = "INSERT INTO group_opening_hours (group_id, day, start_time, end_time) VALUES ";
        for($key=0 ; $key<7 ; $key++) {
            $opening_time = trim($data['opening_time_'.$key]) ? $data['opening_time_'.$key] : NULL;
            $closing_time = trim($data['closing_time_'.$key]) ? $data['closing_time_'.$key] : NULL;
            $sql .= "(" . $group_id . "," . $key . ",'" . $opening_time . "','" . $closing_time . "'),";
        }

        $sql = rtrim($sql, ',') . ";";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(array());

    } catch (PDOException $Exception) {
        return false;
    }

    return true;
}

function modifyGroup($data, $id)
{
    global $pdo;

    $data['g_title'] ? '' : $data['g_title'] = NULL;
    $data['cat_id'] ? '' : $data['cat_id'] = NULL;
    $data['group_image'] ? '' : $data['group_image'] = NULL;
    $data['g_payment_methods'] ? '' : $data['g_payment_methods'] = NULL;
    $data['address'] ? '' : $data['address'] = NULL;
    $data['g_desc'] ? '' : $data['g_desc'] = NULL;
    $data['g_products_and_services'] ? '' : $data['g_products_and_services'] = NULL;
    $data['g_specialities'] ? '' : $data['g_specialities'] = NULL;
    $data['g_languages'] ? '' : $data['g_languages'] = NULL;
    $data['contact_number'] ? '' : $data['contact_number'] = NULL;

    if (isset($data["group_active"])) {
        $data['group_active'] = 1;
    } else {
        $data['group_active'] = 0;
    }

    $data['now'] = date("Y-m-d H:i:s");

    $fields = "SET g_title=?, cat_id=?, g_icon=?, active=?, g_payment_methods=?, address=?, g_desc=?, g_products_and_services=?, g_specialities=?, g_languages=?, contact_number=?, last_updated=?";

    try {
        $stmt = $pdo->prepare("UPDATE groups $fields  WHERE g_id=$id");
        $stmt->execute(
            array(
                $data['g_title'],
                $data['cat_id'],
                $data['group_image'],
                $data['group_active'],
                $data['g_payment_methods'],
                $data['address'],
                $data['g_desc'],
                $data['g_products_and_services'],
                $data['g_specialities'],
                $data['g_languages'],
                $data['contact_number'],
                $data['now']
            ));

        $group_id = $id;
        $sql = "";
        for($key=0 ; $key<7 ; $key++) {
            $opening_time = trim($data['opening_time_'.$key]) ? $data['opening_time_'.$key] : NULL;
            $closing_time = trim($data['closing_time_'.$key]) ? $data['closing_time_'.$key] : NULL;
            $sql .= "UPDATE group_opening_hours 
                    SET start_time='" . $opening_time . "', end_time='" . $closing_time . "' 
                    WHERE day=" . $key . " AND group_id=" . $group_id . ";";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute(array());
    } catch (PDOException $Exception) {
        var_dump($Exception); exit;
        return false;
    }
    return true;
}

function getBusinessHours($id){
    global $pdo;

    $sql = " SELECT * FROM group_opening_hours WHERE group_id=$id ORDER BY day ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}

function searchDataBykeyword($tablename, $col, $data)
{
    global $pdo;

    $sql = " SELECT * FROM $tablename WHERE $col like '%" . $data . "%' LIMIT 20";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = false;
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            $data[] = $row;
        }
    }

    return $data;
}
function getSearchValueTabularCategories($searchdata)
{
    ob_start(null, 0, PHP_OUTPUT_HANDLER_STDFLAGS); // Start Getting the HTML
    ?>

    <?php if ($searchdata) { ?>
    <?php foreach ($searchdata as $count => $entry) { ?>

        <tr>
            <td><input type="checkbox" name="selectedForDelete[]" value="<?= $entry['c_id'] ?>"></td>
            <td><?= $count + 1 ?></td>
            <td><?= $entry['c_name'] ?></td>
            <td><img src="<?= CATEGORIES_IMGS ?><?= $entry['c_icon'] ?>" width="40"></td>
            <td><?= $entry['parent_id'] ?></td>
            <td><?= $entry['last_updated'] ? date("F j, Y, g:i a", strtotime($entry['last_updated'])) : 'Not updated yet' ;  ?></td>
            <td><?php if($entry['active']==1)
                {echo "Yes";}
                else
                {
                    echo "No";
                }?></td>

            <td>
                <div class="btn-group">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                        Actions <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu dropdown-primary pull-right" role="menu">
                        <li>
                            <a href="<?= ADMIN_PAGES . 'categories/modify-category.php?action=edit&id=' . $entry['c_id'] ?>">Edit</a>
                        </li>
                        <li>
                            <a href="<?= ADMIN_PAGES . 'categories/category-actions.php?action=delete&id=' . $entry['c_id'] ?>"
                               onclick="return confirm('Are you sure you want to delete this?');">Delete</a>
                        </li>
                    </ul>
                </div>
            </td>
        </tr>


    <?php } ?>
<?php } else { ?>
    <tr>
        <td colspan="10" style="text-align: center; font-size: 16px">Sorry no record found!</td>
    </tr>
    <br>
<?php } ?>

    <?php
    $htmlData = trim(preg_replace('/>\s+</', '><', ob_get_contents()));
    ob_end_clean();

    return $htmlData;
}