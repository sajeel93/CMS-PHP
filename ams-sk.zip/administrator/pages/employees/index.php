<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php $pageName = "Employees"; ?>
        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <div class="row">
                    <div class="col-sm-9">
                        <h4>All Users &nbsp; &nbsp;
                            <a href="<?= ADMIN_PAGES .  'employees/modify-employee.php' ?>" class="btn btn-blue">
                                Add Employee
                            </a>
                        </h4>
                    </div>
                    <div class="col-sm-3">

                    </div>
                </div>

                <br>

                <div class="well well-sm">
                    <div class="row">
                        <div class="col-sm-4">
                            <select class="form-control" id="selectPerPage" style="width: 80px;display: inline;">
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="150">150</option>
                                <option value="all">All</option>
                            </select>
                            &nbsp; Records per page
                        </div>

                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="searchitems" id="searchitems"
                                   placeholder="Search by Employee's name">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4">
                        <form action="user-actions.php" class="form-inline" id="formSelectedAction" method="post">
                            <input type="hidden" name="action" value="delete-selected">
                            <input type="hidden" id="inputDeleteIds" name="inputDeleteIds" value="">
                            <input type="submit" value="Delete Selected" id="btnDeleteSelected" class="btn btn-red">
                        </form>
                    </div>
                </div>

                <br>

                <table class="table table-bordered responsive">
                    <thead>
                    <tr>
                        <th><input type="checkbox" name="selectedAllForDelete" id="selectedAllForDelete"></th>
                        <th>#</th>
                        <th>Email</th>
                        <th>Full Name</th>
                        <th>Last Login</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <?php

                    // determine page number from $_GET
                    $pageNo = 1;
                    if(!empty($_GET['page'])) {
                        $pageNo = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
                        if(false === $pageNo) {
                            $pageNo = 1;
                        }
                    }

                    // determine per page number from $_GET
                    if($_GET['per_page'] == 'all') {
                        $perPage = $_GET['per_page'];
                    }else {
                        $perPage = PER_PAGE;
                        if (!empty($_GET['per_page'])) {
                            if ($perPage != 'all') {
                                $perPage = filter_input(INPUT_GET, 'per_page', FILTER_VALIDATE_INT);
                                if (false === $pageNo) {
                                    $perPage = PER_PAGE;
                                }
                            }
                        }
                    }

                    $employees = getAllEmployees($pageNo, $perPage);

                    ?>

                    <tbody id="results-search">
                    <?php foreach ($employees as $count => $employee) { ?>
                        <tr>
                            <td><input type="checkbox" name="selectedForDelete[]" value="<?= $user['user_id'] ?>"></td>
                            <td><?= $count + 1 ?></td>
                            <td><?= $employee['email'] ?></td>
                            <td><?= $employee['first_name'] . ' ' . $employee['last_name'] ?></td>
                            <td><?= date("F j, Y, g:i a", strtotime($employee['last_login_date']));  ?></td>
                            <td><?php if($employee['active']==1)
                                {echo "Yes";}
                                else
                                {
                                    echo "No";
                                }?></td>

                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                        Actions <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu dropdown-primary pull-right" role="menu">
                                        <li>
                                            <a href="<?= ADMIN_PAGES . 'employees/modify-employee.php?action=edit&id=' . $employee['user_id'] ?>">Edit</a>
                                        </li>
                                        <li>
                                            <a href="<?= ADMIN_PAGES . 'employees/employee-actions.php?action=delete&id=' . $employee['user_id'] ?>"
                                               onclick="return confirm('Are you sure you want to delete this?');">Delete</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>

                <div class="row">
                    <div class="col-sm-12">
                        <?php echo getPagination($pageNo, $perPage, 'employees'); ?>
                    </div>
                </div>

            </div>
        </div>

        <?php include "../common/footer.php" ?>

    </div>
</div>

<?php include "../common/foot.php" ?>
<script type="text/javascript">

    $(function () {
        searchOnKey(dataSearch);
    });

    var dataSearch = {
        inputSearch: "searchitems",
        url: "employee-actions.php",
        resultElement: "results-search"
    };

</script>

</body>
</html>