<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php if (isset($_GET['id'])) { ?>
            <?php $pageName = "Modify Employee"; ?>
        <?php } else { ?>
            <?php $pageName = "Add an Employee"; ?>
        <?php } ?>

        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <?php $employee = getEmployee($_GET['id']); ?>

                <form role="form" id="form1" method="post" action="employee-actions.php" class="validate" enctype="multipart/form-data">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="panel-title">Employee Information</div>

                            <div class="panel-options">
                                <div style="margin-top: 4px;">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="<?= ADMIN_PAGES ?>users/" class="btn btn-default">Back to All</a>
                                </div>
                            </div>
                        </div>

                        <div class="panel-body">
                            <?php if (isset($_GET['id'])) { ?>
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                            <?php } else { ?>
                                <input type="hidden" name="action" value="add">
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">First Name</label>

                                        <input type="text" class="form-control" name="first_name"
                                               data-validate="required"
                                               data-message-required="First Name is Invalid"
                                               value="<?= $employee['first_name'] ?>"
                                               placeholder="Required Field"/>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Last Name</label>
                                        <input type="text" class="form-control" name="last_name"
                                               data-validate="required"
                                               data-message-required="Last Name is Invalid"
                                               value="<?= $employee['last_name'] ?>"
                                               placeholder="Required Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Email</label>
                                        <input type="text" class="form-control" name="email_address"
                                               data-validate="email,required" data-message-required="Email is Invalid"
                                               value="<?= $employee['email'] ?>" placeholder="Email Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Gender</label>
                                        <select class="form-control" name="gender" id="userGender">
                                            <option value="" disabled selected>Select Gender</option>
                                            <option value="male" selected>Male</option>
                                            <option value="female">Female</option>
                                        </select>
                                        <script>
                                            var selectUserGender= $('#userGender');
                                            var userGender = '<?= $employee['gender'] ?>';
                                            selectUserGender.val(userGender);
                                        </script>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Number</label>
                                        <input type="text" class="form-control" name="number" data-validate="number"
                                               value="<?= $employee['phone_no'] ?>" placeholder="Phone Number"/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Active User &nbsp;</label><br>
                                        <div class="make-switch switch-mini" data-on-label="Yes" data-off-label="No">
                                            <input type="checkbox" checked="true" name="employee_active" <?php if ($employee['active']) { echo 'checked="checked"'; } ?>>
                                        </div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                                <br>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="hidden" name="old_employee_image" value="<?= $employee['avatar'] ?>">
                                        <label class="col-sm-4 control-label" style="padding-left: 0;">Employee Image</label>
                                        <div class="col-sm-8">

                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail"
                                                     style="width: 150px; height: 115px;"
                                                     data-trigger="fileinput">
                                                    <?php if($employee['avatar']) { ?>
                                                    <img src="<?= USER_IMAGES ?><?= $employee['avatar'] ?>">
                                                    <?php } else { ?>
                                                    <img src="http://placehold.it/200x150" alt="...">
                                                    <?php } ?>
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail"
                                                     style="max-width: 100px; max-height: 150px"></div>
                                                <div>
                                                <span class="btn btn-white btn-file">
                                                    <span class="fileinput-new">Select image</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="employee_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-orange fileinput-exists"
                                                       data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                           <div class="panel-options">
                               <button type="submit" class="btn btn-success">Submit</button>
                               <a href="<?= ADMIN_PAGES ?>users/" class="btn btn-default">Back to All</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../common/footer.php" ?>

</div>
</div>

<?php include "../common/foot.php" ?>

<script src="<?= ADMIN_JS ?>jquery.validate.min.js"></script>
<script src="<?= ADMIN_JS ?>fileinput.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-switch.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-datepicker.js"></script>

</body>
</html>