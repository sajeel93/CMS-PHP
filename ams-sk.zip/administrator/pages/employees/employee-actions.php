<?php
require "../../config/configuration.php";

if (isset($_POST['action']) && $_POST['action'] == "add") {

    var_dump($_FILES);
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'employee_image', DIR_USERS_IMGS, false);

    if($isUploaded) {
        $_POST['employee_image'] = $isUploaded;
    }else {
        $_POST['employee_image'] = '';
    }

    // inserting new user
    $inserted = addEmployee($_POST);

    // Set response
    if($inserted) {
        makeSessionResponse('success', 'Employees', 'You have successfully added a Employee.');
    } else {
        makeSessionResponse('error', 'Employees', 'You have an error while adding a Employee.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/employees';
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == "edit") {
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'employee_image', DIR_USERS_IMGS, $_POST['old_employee_image']);

    if($isUploaded) {
        $_POST['employee_image'] = $isUploaded;
    }else {
        $_POST['employee_image'] = $_POST['old_employee_image'];
    }

    // updating new user
    $inserted = modifyEmployee($_POST, $_POST['id']);

    $redirect_url = SITEURL_ADMIN . 'pages/employees';
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "delete") {
    // delete user
    $deleted = deleteQuery($_GET['id'], 'users', 'user_id');

    $redirect_url = SITEURL_ADMIN . 'pages/employees';
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == 'delete-selected') {
    // Get player Ids from POST
    $deleteIds = explode(',', $_POST['inputDeleteIds']);

    $response = true;
    $response = deleteQueryForIds($_POST['inputDeleteIds'], 'employees', 'user_id');

    // Set response
    if($response) {
        makeSessionResponse('success', 'Employees', 'You have successfully deleted selected Employees.');
    }else {
        makeSessionResponse('error', 'Employees', 'You have an error while deleting selected Employees.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/employees';
    redirect($redirect_url);
}
elseif(isset($_GET['search_keyword']) && $_GET['action'] == "search") {
    $Users =searchPlayerkeyword('employees', 'first_name',$_GET['search_keyword']);
    $ajaxResponse['htmlData'] = get_user_search_value($Users);
    echo json_encode($ajaxResponse);

}

