<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php $pageName = "Users"; ?>
        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <h4>Striped Rows</h4>

                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Address</th>
                    </tr>
                    </thead>

                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>Arlind</td>
                        <td>Nushi</td>
                    </tr>

                    <tr>
                        <td>2</td>
                        <td>Art</td>
                        <td>Ramadani</td>
                    </tr>

                    <tr>
                        <td>3</td>
                        <td>Filan</td>
                        <td>Fisteku</td>
                    </tr>
                    </tbody>
                </table>

            </div>
        </div>

        <?php include "../common/footer.php" ?>

    </div>
</div>

<?php include "../common/foot.php" ?>

</body>
</html>