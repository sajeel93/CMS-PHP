<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php $pageName = "User's Complaints"; ?>
        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">
                <div class="well well-sm">
                    <div class="row">
                        <div class="col-sm-4">
                            <select class="form-control" id="selectPerPage" style="width: 80px;display: inline;">
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="150">150</option>
                                <option value="all">All</option>
                            </select>
                            &nbsp; Records per page
                        </div>

                        <div class="col-sm-6">
                            <select class="form-control" id="selectFilterBy">
                                <option value="">All Complaints</option>
                                <option value="unread">Unread Complaints</option>
                                <option value="read">Read Complaints</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4">
                        <form action="support-actions.php" class="form-inline" id="formSelectedAction"
                              method="post">
                            <input type="hidden" name="action" value="delete-selected">
                            <input type="hidden" id="inputDeleteIds" name="inputDeleteIds" value="">
                            <button type="submit" id="btnDeleteSelected" class="btn btn-red">
                                <i class="entypo-trash"></i> Delete Selected
                            </button>
                        </form>
                    </div>
                </div>

                <br>

                <table class="table table-bordered responsive">
                    <thead>
                    <tr>
                        <th><input type="checkbox" name="selectedAllForDelete" id="selectedAllForDelete"></th>
                        <th>#</th>
                        <th>Email</th>
                        <th>Full Name</th>
                        <th>Tournament</th>
                        <th>Subject</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <?php

                    // determine page number from $_GET
                    $pageNo = 1;
                    if (!empty($_GET['page'])) {
                        $pageNo = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
                        if (false === $pageNo) {
                            $pageNo = 1;
                        }
                    }

                    // determine per page number from $_GET
                    if ($_GET['per_page'] == 'all') {
                        $perPage = $_GET['per_page'];
                    } else {
                        $perPage = PER_PAGE;
                        if (!empty($_GET['per_page'])) {
                            if ($perPage != 'all') {
                                $perPage = filter_input(INPUT_GET, 'per_page', FILTER_VALIDATE_INT);
                                if (false === $pageNo) {
                                    $perPage = PER_PAGE;
                                }
                            }
                        }
                    }

                    if (isset($_GET['filter'])) {
                        $filter = $_GET['filter'];
                        switch ($filter) {
                            case 'read':
                                $complaints = getReadComplaints(false, 'all');
                                break;
                            case 'unread':
                                $complaints = getUnreadComplaints(false, 'all');
                                break;
                            default:
                                $complaints = array();
                                break;
                        }
                    } else {
                        $complaints = getAllComplaints($pageNo, $perPage);
                    }

                    ?>
                    <tbody>
                    <?php if ($complaints) : ?>
                        <?php foreach ($complaints as $count => $complaint) { ?>
                            <?php $user = getUser($complaint['user_id']); ?>
                            <?php $tournament = $complaint['tournament_id'] ? getTournaments($complaint['tournament_id']): array('tournament_name' => "General"); ?>
                            <tr class="<?= $complaint['status'] ? 'bg-light-green': 'bg-light-red'; ?>">
                                <td>
                                    <input type="checkbox" name="selectedForDelete[]"
                                           value="<?= $complaint['complaint_id'] ?>">
                                </td>
                                <td><?= $count + 1 ?></td>
                                <td><?= $user['email'] ?></td>
                                <td><?= $user['first_name']." ".$user['last_name'] ?></td>
                                <td><?= $tournament['tournament_name'] ?></td>
                                <td><?= $complaint['title'] ?></td>
                                <td><?= $complaint['details'] ?></td>
                                <td><?= $complaint['created_at'] ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-primary dropdown-toggle"
                                                data-toggle="dropdown">
                                            Actions <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-primary pull-right" role="menu">
                                            <?php if ($complaint['status']) { ?>
                                                <li>
                                                    <a href="<?= ADMIN_PAGES . 'support/support-actions.php?action=unread&id=' . $complaint['complaint_id'] ?>">Mark
                                                        Unread</a>
                                                </li>
                                            <?php } else {  ?>
                                                <li>
                                                    <a href="<?= ADMIN_PAGES . 'support/support-actions.php?action=read&id=' . $complaint['complaint_id'] ?>">Mark
                                                        Read</a>
                                                </li>
                                            <?php }  ?>
                                            <li>
                                                <a href="<?= ADMIN_PAGES . 'support/support-actions.php?action=delete&id=' . $complaint['complaint_id'] ?>"
                                                   onclick="return confirm('Are you sure you want to delete this?');">Delete</a>
                                            </li>

                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="25" class="text-center">Sorry No Record found!</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>

                </table>

                <?php if (!isset($_GET['filter'])) { ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo getPagination($pageNo, $perPage, 'complaints'); ?>
                        </div>
                    </div>
                <?php } ?>


            </div>
        </div>

        <?php include "../common/footer.php" ?>

    </div>
</div>

<?php include "../common/foot.php" ?>
<script>
    var selectFilterBy = $('#selectFilterBy');
    var getFilter = '<?= $_GET['filter'] ?>';

    selectFilterBy.val(getFilter);

    selectFilterBy.on('change', function () {
        var getFilter = $(this).val();

        if (getFilter) {
            if (checkQueryStringExist()) {
                getFilter = '&filter=' + getFilter;
            } else {
                getFilter = '?filter=' + getFilter;
            }

            window.location.href = '<?= $_SERVER['PHP_SELF']; ?>' + getFilter;
        } else {
            window.location.href = '<?= $_SERVER['PHP_SELF']; ?>';
        }
    });
</script>
</body>
</html>