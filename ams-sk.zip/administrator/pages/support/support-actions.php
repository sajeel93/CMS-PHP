<?php
require "../../config/configuration.php";

if (isset($_GET['action']) && $_GET['action'] == "read") {

    $updated = updateReadComplaint(1, $_GET['id']);

    // Set response
    if($updated) {
        makeSessionResponse('success', 'Complaint', 'You have successfully mark read of Complaint.');
    } else {
        makeSessionResponse('error', 'Complaint', 'You have an error while marking a Complaint.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/support';
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "unread") {

    $updated = updateReadComplaint(0, $_GET['id']);

    // Set response
    if($updated) {
        makeSessionResponse('success', 'Complaint', 'You have successfully mark unread of Complaint.');
    } else {
        makeSessionResponse('error', 'Complaint', 'You have an error while marking a Complaint.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/support';
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "delete") {
    // delete user
    $deleted = deleteQuery($_GET['id'], 'complaints', 'complaint_id');

    // Set response
    if($deleted) {
        makeSessionResponse('success', 'Complaint', 'You have successfully deleted a Complaint.');
    }else {
        makeSessionResponse('error', 'Complaint', 'You have an error while deleting Complaint.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/support';
    redirect($redirect_url);
}elseif (isset($_POST['action']) && $_POST['action'] == 'delete-selected') {
    // Get player Ids from POST
    $deleteIds = explode(',', $_POST['inputDeleteIds']);

    $response = true;
    $response = deleteQueryForIds($_POST['inputDeleteIds'], 'complaints', 'complaint_id');

    // Set response
    if($response) {
        makeSessionResponse('success', 'Complaint', 'You have successfully deleted selected Complaints.');
    }else {
        makeSessionResponse('error', 'Complaint', 'You have an error while deleting selected Complaints.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/support';
    redirect($redirect_url);
}


