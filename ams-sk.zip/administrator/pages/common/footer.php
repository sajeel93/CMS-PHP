<div class="hidden">
    <br/>
    <!-- Footer -->
    <footer class="main">

        &copy; 2014 <strong>FantasyCricket</strong> Theme by <a href="http://laborator.co" target="_blank">Nauman Bhatti</a>

    </footer>
</div>
