<header class="logo-env">

    <!-- logo -->
    <div class="logo">
        <a href="<?= ADMIN_PAGES ?>dashboard/">
            <h3 style="color: #FFF;font-family: 'Arial Black', Sans-Serif;margin: 0;margin-left: -10px;margin-top: 4px;">
                TSG</h3>
        </a>
    </div>

    <!-- logo collapse icon -->
    <div class="sidebar-collapse">
        <a href="#" class="sidebar-collapse-icon with-animation">
            <!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
            <i class="entypo-menu"></i>
        </a>
    </div>

    <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
    <div class="sidebar-mobile-menu visible-xs">
        <a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
            <i class="entypo-menu"></i>
        </a>
    </div>

</header>

<?php
$full_link = explode('/', trim($_SERVER[REQUEST_URI]));
$currentLink = "";
if(isset($full_link[3])) {
    $currentLink = $full_link[3];
}

$sidebar = array();

$sidebar[] = array(
    'name' => 'Dashboard',
    'link' => 'dashboard/',
    'icon' => 'entypo-gauge',
    'childs' => false
);

$sidebar[] = array(
    'name' => 'Manager Admin',
    'link' => 'manager-admin/',
    'icon' => 'entypo-lock',
    'childs' => false

);

$sidebar[] = array(
    'name' => 'Employees',
    'link' => 'employees/',
    'icon' => 'entypo-users',
    'childs' => false

);

/* $sidebar[] = array(
    'name' => 'Site Settings',
    'link' => 'site-settings/',
    'icon' => 'entypo-cog',
    'childs' => false
);
$sidebar[] = array(
    'name' => 'Categories',
    'link' => 'categories/',
    'icon' => 'entypo-layout',
    'childs' => false

);

$sidebar[] = array(
    'name' => 'Groups',
    'link' => 'groups/',
    'icon' => 'entypo-layout',
    'childs' => false

);

$sidebar[] = array(
    'name' => 'Support',
    'link' => 'support/?filter=unread',
    'icon' => 'entypo-mail',
    'childs' => false
);*/
?>

<ul id="main-menu" class="auto-inherit-active-class">
    <!-- add class "multiple-expanded" to allow multiple submenus to open -->
    <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->

    <?php foreach ($sidebar as $sidebar_item) { ?>
        <?php
        $active = '';
        $variable = str_replace('/','', $sidebar_item['link']);
        if (strpos($variable, '?') !== false) {
            $variable = substr($variable, 0, strpos($variable, "?"));
        }
        if ($currentLink == $variable)
            $active = 'active';
        ?>
        <li class="root-level <?= $active ?>"> <!-- add class "opened" to open -->
            <a href="<?= ADMIN_PAGES . $sidebar_item['link'] ?>">
                <i class="<?= $sidebar_item['icon'] ?>"></i>
                <span><?= $sidebar_item['name'] ?></span>
            </a>
            <?php if ($sidebar_item['childs']) { ?>
                <ul>
                    <?php foreach ($sidebar_item['childs'] as $item_child) { ?>
                        <li class=""> <!-- add class "opened" to active effect -->
                            <a href="<?= ADMIN_PAGES . $item_child['link'] ?>">
                                <span><?= $item_child['name'] ?></span>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            <?php } ?>
        </li>
    <?php } ?>
</ul>