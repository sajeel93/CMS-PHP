<!-- Bottom Scripts -->
<script src="<?= ADMIN_JS ?>gsap/main-gsap.js"></script>
<script src="<?= ADMIN_JS ?>jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap.js"></script>
<script src="<?= ADMIN_JS ?>joinable.js"></script>
<script src="<?= ADMIN_JS ?>resizeable.js"></script>
<script src="<?= ADMIN_JS ?>neon-api.js"></script>
<script src="<?= ADMIN_JS ?>neon-custom.js"></script>
<script src="<?= ADMIN_JS ?>neon-demo.js"></script>
<script src="<?= ADMIN_JS ?>toastr.js"></script>

<script>
    var selectPerPage = $('#selectPerPage');
    var perpage = '<?= $perPage ?>';

    selectPerPage.val(perpage);

    selectPerPage.on('change', function () {
        var perpage = $(this).val();

        if (perpage) {
            if (checkQueryStringExist()) {
                perpage = '&per_page=' + perpage;
            } else {
                perpage = '?per_page=' + perpage;
            }

            window.location.href = '<?= $_SERVER['PHP_SELF']; ?>' + perpage;
        }
    });

    $('#formSelectedAction').on('submit', function (e) {
        e.preventDefault();
        var deleteIds = [];

        $("input[name='selectedForDelete[]']:checked").each(function () {
            deleteIds.push($(this).val());
        });

        if (deleteIds.length > 0) {
            var confirmation = confirm('Are you sure you want to delete this?');
            if (confirmation) {
                $('#inputDeleteIds').val(deleteIds.join(','));
                $('#formSelectedAction')[0].submit();
            }
        } else {
            e.preventDefault();
            showToaster('warning', 'Choose Values', 'You must choose atleast one entry.');
        }
    });

    $('#selectedAllForDelete').on('click', function (e) {
        var value = $(this).prop('checked');
        if(value) {
            $("input[name='selectedForDelete[]']").prop('checked', true);
            $("input[name='selectedPlayers[]']").prop('checked', true);
        }else {
            $("input[name='selectedForDelete[]']").prop('checked', false);
            $("input[name='selectedPlayers[]']").prop('checked', false);
        }
    });

    //use for searching
    var searchRequest = null;
    function searchOnKey(dataSearch) {
        $("#" + dataSearch.inputSearch).keyup(function () {
            var inputElement = this,
                value = $(this).val();
            var output = '';

            if (value.length >= 2 || value.length == 0) {
                if (searchRequest != null)
                    searchRequest.abort();
                searchRequest = $.ajax({
                    type: "GET",
                    url: dataSearch.url,
                    data: {
                        'search_keyword': value,
                        'action': "search"
                    },
                    dataType: "text",
                    success: function (result) {
                        //we need to check if the value is the same
                        if (value == $(inputElement).val()) {
                            var data = JSON.parse(result);
                            $('#' + dataSearch.resultElement).html(data.htmlData);
                        }
                        $('.pagination').hide();
                    }
                });
            } else {
                $('.pagination').show();
            }
        });
    }
    if($("#searchitems").length != 0) {
        $(window).scroll(function () {
            if ($('#searchitems').val().length == 0) {
                $('.pagination').show();
            }
        });
    }
</script>