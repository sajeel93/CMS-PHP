<div class="row">
    <!-- Profile Info and Notifications -->
    <div class="col-md-6 col-sm-8 clearfix">

        <?php if(!isset($pageName)) {
            $pageName = "Undefined Page";
        } ?>

        <h1><?= $pageName ?></h1>

    </div>

    <!-- Raw Links -->
    <div class="col-md-6 col-sm-4 clearfix hidden-xs">

        <ul class="list-inline links-list pull-right">
            <li class="profile-info dropdown">
                <!-- add class "pull-right" if you want to place this from right -->

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <img src="<?= ADMIN_IMAGES ?>sample-crop.jpg" alt="" class="img-circle" width="20" height="20">
                    <?= $_SESSION['admin_name'] ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu">

                    <!-- Reverse Caret -->
                    <li class="caret"></li>

                    <li>
                        <a href="<?= ADMIN_PAGES . 'site-settings/'?>">
                            <i class="entypo-cog"></i>
                            Settings
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?= SITEURL_ADMIN ?>actions/action-logout.php">
                    Log Out <i class="entypo-logout right"></i>
                </a>
            </li>
        </ul>

    </div>

</div>