<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>Admin | TSG</title>

<link rel="shortcut icon" href="<?= SITEURL_ADMIN ?>favicon.ico" type="image/x-icon">
<link rel="icon" href="<?= SITEURL_ADMIN ?>favicon.ico" type="image/x-icon">

<link rel="stylesheet" href="<?= ADMIN_JS ?>jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>font-icons/entypo/css/entypo.css">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>bootstrap.css">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>neon-core.css">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>neon-theme.css">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>neon-forms.css">
<link rel="stylesheet" href="<?= ADMIN_CSS ?>custom.css">

<script src="<?= ADMIN_JS ?>jquery-1.11.0.min.js"></script>

<!--[if lt IE 9]>
<script src="<?= ADMIN_JS ?>ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<script>
    function checkQueryStringExist() {
        var field = 'q';
        var url = window.location.href;
        if (url.indexOf('?' + field + '=') != -1)
            return true;
        else if (url.indexOf('&' + field + '=') != -1)
            return true;
        return false
    }

    function showToaster($type, title, msg) {
        var color;
        if($type == 'success') {
            color = 'green';
        } else if($type == 'error') {
            color = 'red';
        } else if($type == 'warning') {
            color = 'orange';
        }else {
            color = "black";
        }
        var opts = {
            "closeButton": true,
            "debug": false,
            "positionClass": "toast-top-right",
            "toastClass": color,
            "onclick": null,
            "showDuration": "1000",
            "hideDuration": "2000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };

        if($type == 'success') {
            toastr.success(msg, title, opts);
        } else if($type == 'error') {
            toastr.error(msg, title, opts);
        } else if($type == 'warning') {
            toastr.warning(msg, title, opts);
        }else {
            toastr.success(msg, title, opts);
        }
    }

    <?php if(isset($_SESSION['response'])) { ?>
        var toaserTitle = "<?= $_SESSION['response']['title'] ?>";
        var toasermsg = "<?= $_SESSION['response']['desc'] ?>";

        setTimeout(function () {
            showToaster('<?= $_SESSION['response']['type'] ?>', toaserTitle, toasermsg);
        }, 1000);

        <?php unset($_SESSION['response']); ?>
    <?php } ?>
</script>