<?php
require "../../config/configuration.php";

if (isset($_POST['action']) && $_POST['action'] == "add") {
    // inserting new user
    $inserted = addAdminUser($_POST);

    // Set response
    if($inserted) {
        makeSessionResponse('success', 'Manager Admin', 'You have successfully added an admin user.');
    } else {
        makeSessionResponse('error', 'Manager Admin', 'You have an error while adding an admin user.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/manager-admin';
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == "edit") {

    // updating new user
    $updated = modifyAdminUser($_POST, $_POST['id']);

    // Set response
    if($updated) {
        makeSessionResponse('success', 'Manager Admin', 'You have successfully updated an admin user.');
    } else {
        makeSessionResponse('error', 'Manager Admin', 'You have an error while updating an admin user.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/manager-admin';
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "delete") {
    // delete user
    $deleted = deleteQuery($_GET['id'], 'fc_admin_users', 'fc_admin_id');

    // Set response
    if($deleted) {
        makeSessionResponse('success', 'Manager Admin', 'You have successfully deleted an admin user.');
    } else {
        makeSessionResponse('error', 'Manager Admin', 'You have an error while deleting an admin user.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/manager-admin';
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == 'delete-selected') {
    // Get player Ids from POST
    $deleteIds = explode(',', $_POST['inputDeleteIds']);

    $response = true;
    $response = deleteQueryForIds($_POST['inputDeleteIds'], 'fc_admin_users', 'fc_admin_id');

    // Set response
    if($response) {
        makeSessionResponse('success', 'Manager Admin', 'You have successfully deleted selected admin users.');
    }else {
        makeSessionResponse('error', 'Manager Admin', 'You have an error while deleting selected admin users.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/manager-admin';
    redirect($redirect_url);
}
elseif(isset($_GET['search_keyword']) && $_GET['action'] == "search") {

    $Users =searchPlayerkeyword('fc_admin_users', 'fc_admin_first_name', $_GET['search_keyword']);
    $ajaxResponse['htmlData'] = get_user_search_value($Users);
    echo json_encode($ajaxResponse);

}

