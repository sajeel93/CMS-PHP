<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php if (isset($_GET['id'])) { ?>
            <?php $pageName = "Modify Admin User"; ?>
        <?php } else { ?>
            <?php $pageName = "Add a Admin User"; ?>
        <?php } ?>

        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <?php $user = getAdminUser($_GET['id']); ?>

                <form role="form" id="form1" method="post" action="admin-user-actions.php" class="validate">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="panel-title">Admin User Information</div>

                            <div class="panel-options">
                                <div style="margin-top: 4px;">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="<?= ADMIN_PAGES ?>manager-admin/" class="btn btn-default">Back to All</a>
                                </div>
                            </div>
                        </div>

                        <div class="panel-body">
                            <?php if (isset($_GET['id'])) { ?>
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                            <?php } else { ?>
                                <input type="hidden" name="action" value="add">
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">First Name</label>

                                        <input type="text" class="form-control" name="first_name"
                                               data-validate="required"
                                               data-message-required="First Name is Invalid"
                                               value="<?= $user['fc_admin_first_name'] ?>"
                                               placeholder="Required Field"/>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Last Name</label>
                                        <input type="text" class="form-control" name="last_name"
                                               data-validate="required"
                                               data-message-required="Last Name is Invalid"
                                               value="<?= $user['fc_admin_last_name'] ?>"
                                               placeholder="Required Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Username</label>
                                        <input type="text" class="form-control" name="username"
                                               data-message-required="Username is Invalid"
                                               value="<?= $user['fc_admin_username'] ?>" placeholder="Username Field"/>
                                    </div>
                                </div>

                                <?php if(isset($_GET['id'])) {?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">Update Password</label>
                                            <div class="make-switch switch-mini" data-on-label="Yes" data-off-label="No">
                                                <input type="checkbox" name="change_password" id="checkboxChangePassword">
                                            </div>
                                            <input style="visibility: hidden;" type="text" class="form-control" name="password"
                                                   id="inputPassword"
                                                   data-message-required="Password is Invalid"
                                                   value="********"
                                                   placeholder="Required Field"/>
                                        </div>
                                    </div>
                                <?php }else {?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">Password</label>
                                            <input type="text" class="form-control" name="password"
                                                   data-validate="required" id="inputPassword"
                                                   data-message-required="Password is Invalid"
                                                   placeholder="Required Field"/>
                                        </div>
                                    </div>
                                <?php }?>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Email</label>
                                        <input type="text" class="form-control" name="email_address"
                                               data-validate="email,required" data-message-required="Email is Invalid"
                                               value="<?= $user['fc_admin_email'] ?>" placeholder="Email Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Default page</label>
                                        <input type="text" class="form-control" name="default_page"
                                               data-validate="" data-message-required="Default page is Invalid"
                                               value="<?= $user['fc_admin_default_page'] ?>" placeholder="Default page Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Admin Group</label>
                                        <input type="text" class="form-control" name="admin_group"
                                               data-validate="required" data-message-required="Admin Group is Invalid"
                                               value="<?= $user['fc_admin_group'] ?>" placeholder="Admin Group Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Make user status Active</label> &nbsp;
                                        <div class="make-switch switch-mini" data-on-label="Yes" data-off-label="No">
                                            <input type="checkbox" name="admin_status" <?php if ($user['fc_admin_status']) {
                                                echo 'checked="checked"';
                                            } ?>>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <div class="panel-options">
                                <button type="submit" class="btn btn-success">Submit</button>
                                <a href="<?= ADMIN_PAGES ?>manager-admin/" class="btn btn-default">Back to All</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../common/footer.php" ?>

</div>
</div>

<?php include "../common/foot.php" ?>

<script src="<?= ADMIN_JS ?>jquery.validate.min.js"></script>
<script src="<?= ADMIN_JS ?>fileinput.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-switch.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-datepicker.js"></script>
<script>
    $(function () {
       $('#checkboxChangePassword').on('change', function() {
           var valueChangePassword = $(this).prop('checked');
           if(valueChangePassword) {
               $('#inputPassword').css('visibility', 'visible');
           }else {
               $('#inputPassword').css('visibility', 'hidden');
           }
       });
    });
</script>

</body>
</html>