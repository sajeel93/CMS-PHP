<?php
require "../../config/configuration.php";

if (isset($_POST['action']) && $_POST['action'] == "edit") {
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'logoimage', DIR_IMGS, $_POST['old_logoimage']);

    if($isUploaded) {
        $_POST['logoimage'] = $isUploaded;
    }else {
        $_POST['logoimage'] = $_POST['old_logoimage'];
    }

    // updating new user
    $updated = modifySetting($_POST);

    // Set response
    if($updated) {
        makeSessionResponse('success', 'Site Settings', 'You have successfully updated site settings.');
    } else {
        makeSessionResponse('error', 'Users', 'You have an error while updating site settings.');
    }

    $redirect_url = SITEURL_ADMIN . 'pages/site-settings';
    redirect($redirect_url);
}

