<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php $pageName = "Site Settings"; ?>

        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <?php $setting = getSetting(); ?>

                <form role="form" id="form1" method="post" action="site-settings-actions.php" class="validate"
                      enctype="multipart/form-data">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="panel-title">Site Information</div>

                            <div class="panel-options">
                                <div style="margin-top: 4px;">
                                    <button type="submit" class="btn btn-success">Save Settings</button>
                                </div>
                            </div>
                        </div>

                        <div class="panel-body">
                            <input type="hidden" name="action" value="edit">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="">
                                        <label class="control-label" style="font-size: 16px; margin-top: 5px;">
                                            Do you want to make site down for maintenance?
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="">
                                        <div class="make-switch" data-on-label="Yes" data-off-label="No">
                                            <input type="checkbox" name="site_live" <?php if (!$setting['site_live']) {
                                                echo 'checked="checked"';
                                            } ?>>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <hr>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Sitename</label>
                                        <input type="text" class="form-control" name="sitename"
                                               data-validate="required" data-message-required="Sitename is Invalid"
                                               value="<?= $setting['sitename'] ?>" placeholder="Sitename Field"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Phone Number</label>
                                        <input type="text" class="form-control" name="phonenum"
                                               value="<?= $setting['phonenum'] ?>" placeholder="Phone Number"/>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">pinterest</label>
                                        <input type="text" class="form-control" name="pinterest"
                                               value="<?= $setting['pinterest'] ?>" placeholder="pinterest"/>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">linkedin</label>
                                        <input type="text" class="form-control" name="linkedin"
                                               value="<?= $setting['linkedin'] ?>" placeholder="linkedin"/>
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <div class="panel-options">
                                <button type="submit" class="btn btn-success">Save Settings</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../common/footer.php" ?>

</div>
</div>

<?php include "../common/foot.php" ?>

<script src="<?= ADMIN_JS ?>jquery.validate.min.js"></script>
<script src="<?= ADMIN_JS ?>fileinput.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-switch.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-datepicker.js"></script>

</body>
</html>