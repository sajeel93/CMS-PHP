<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body  page-fade">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php $pageName = "Dashbaord"; ?>

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php include "../common/topbar.php" ?>

        <hr/>


        <div class="row">
            <div class="col-sm-3">

                <div class="tile-stats tile-red">
                    <div class="icon"><i class="entypo-users"></i></div>
                    <div class="num" data-start="0" data-end="12" data-postfix=""
                         data-duration="1500" data-delay="0">
                        0
                    </div>

                    <h3>Registered users</h3>
                    <p>so far in our website.</p>
                </div>

            </div>
        </div>

        <br/>

        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="panel-title">Latest Logined Users</div>
                    </div>

                    <table class="table table-bordered table-responsive">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Login Time</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                        /* $users = getTopLastLoginedUsers();
                        foreach ($users as $count => $user) { ?>
                            <tr>
                                <td><?= $count + 1 ?></td>
                                <td><?= $user['first_name'] . " " . $user['last_name'] ?></td>
                                <td><?= $user['email'] ?></td>
                                <td>
                                    <span class="inlinebar">
                                        <?= date("F j, Y, g:i a", strtotime($user['last_login_date'])); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php } */ ?>

                        </tbody>
                    </table>
                </div>

            </div>

        </div>

        <?php include "../common/footer.php" ?>
    </div>

</div>

<!-- Bottom Scripts -->
<?php include "../common/foot.php" ?>
<script src="<?= ADMIN_JS ?>raphael-min.js"></script>
<script src="<?= ADMIN_JS ?>jquery.peity.min.js"></script>
<script src="<?= ADMIN_JS ?>morris.min.js"></script>
<script src="<?= ADMIN_JS ?>jquery.sparkline.min.js"></script>
<script src="<?= ADMIN_JS ?>joinable.js"></script>
</body>
</html>