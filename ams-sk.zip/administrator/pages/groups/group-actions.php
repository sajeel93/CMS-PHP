<?php
require "../../config/configuration.php";

define('TABLE_NAME', 'groups');
define('LABEL_SINGLE', 'Group');
define('LABEL_PLURAL', 'Groups');
define('TABLE_PRIMARY_KEY', 'g_id');
define('ROOT_PATH', 'pages/groups');

if (isset($_POST['action']) && $_POST['action'] == "add") {

    var_dump($_FILES);
    // Upload image
    $isUploaded = uploadFile($_FILES, 'group_image', DIR_GROUPS, false);

    if($isUploaded) {
        $_POST['group_image'] = $isUploaded;
    } else {
        $_POST['group_image'] = '';
    }

    // inserting new
    $inserted = addGroup($_POST);

    // Set response
    if($inserted) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully added a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while adding a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == "edit") {
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'group_image', DIR_GROUPS, $_POST['old_group_image']);

    if($isUploaded) {
        $_POST['group_image'] = $isUploaded;
    } else {
        $_POST['group_image'] = $_POST['old_group_image'];
    }

    // updating new
    $updated = modifyGroup($_POST, $_POST['id']);

    // Set response
    if($updated) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully updated a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while updating a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "delete") {
    // delete
    $deleted = deleteQuery($_GET['id'], TABLE_NAME, TABLE_PRIMARY_KEY);

    // Set response
    if($deleted) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully deleted a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while deleting a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == 'delete-selected') {
    // Get player Ids from POST
    $deleteIds = explode(',', $_POST['inputDeleteIds']);

    $response = true;
    $response = deleteQueryForIds($_POST['inputDeleteIds'], TABLE_NAME, TABLE_PRIMARY_KEY);

    // Set response
    if($response) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully deleted selected ' . LABEL_PLURAL . '.');
    }else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while deleting selected ' . LABEL_PLURAL . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
}
elseif(isset($_GET['search_keyword']) && $_GET['action'] == "search") {

    $data =searchDataBykeyword(TABLE_NAME, 'g_title',$_GET['search_keyword']);
    $ajaxResponse['htmlData'] = getSearchValueTabularGroups($data);
    echo json_encode($ajaxResponse);
}

