<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php if (isset($_GET['id'])) { ?>
            <?php $pageName = "Modify Group"; ?>
        <?php } else { ?>
            <?php $pageName = "Add a Group"; ?>
        <?php } ?>

        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <?php $entry = getGroup($_GET['id']); ?>

                <form role="form" id="form1" method="post" action="group-actions.php" class="validate" enctype="multipart/form-data">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="panel-title">Group Information</div>

                            <div class="panel-options">
                                <div style="margin-top: 4px;">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="<?= ADMIN_PAGES ?>groups/" class="btn btn-default">Back to All</a>
                                </div>
                            </div>
                        </div>

                        <div class="panel-body">
                            <?php if (isset($_GET['id'])) { ?>
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                            <?php } else { ?>
                                <input type="hidden" name="action" value="add">
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Group Title</label>

                                        <input type="text" class="form-control" name="g_title"
                                               data-validate="required"
                                               value="<?= $entry['g_title'] ?>"
                                               placeholder="Enter your group name"/>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Category</label>
                                        <select class="form-control" name="cat_id" id="catId">
                                            <option value="0" selected>Select a Category</option>
                                            <?php 
                                            $categories = getAllCategories(false, 'all');
                                            foreach ($categories as $key => $entrySelect) { ?>
                                                <?php if (isset($_GET['id']) && $entrySelect['c_id'] == $_GET['id']) { ?>
                                                    <!-- Do Nothing -->
                                                <?php } else { ?>
                                                    <option value="<?= $entrySelect['c_id']; ?>"><?= $entrySelect['c_name']; ?></option>
                                                <?php } ?>                                                
                                            <?php } ?>
                                        </select>
                                        <script>
                                            var selectCatId= $('#catId');
                                            var catId = '<?= $entry['cat_id'] ?>';
                                            selectCatId.val(catId);
                                        </script>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Group Contact #</label>
                                        <input type="text" class="form-control" name="contact_number"
                                               value="<?= $entry['contact_number'] ?>"
                                               placeholder="Enter contact number of the group" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Payment Methods <small>(seperated by comma)</small></label>
                                        <textarea rows="4" class="form-control" name="g_payment_methods"><?= $entry['g_payment_methods'] ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Address</label>
                                        <textarea rows="4" class="form-control" name="address"><?= $entry['address'] ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Description</label>
                                        <textarea rows="4" class="form-control" name="g_desc"><?= $entry['g_desc'] ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">
                                            Products &amp; Services <small>(seperated by comma)</small>
                                        </label>
                                        <textarea rows="4" class="form-control" name="g_products_and_services"><?= $entry['g_products_and_services'] ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Specialities <small>(seperated by comma)</small></label>
                                        <textarea rows="4" class="form-control" name="g_specialities"><?= $entry['g_specialities'] ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Languages <small>(seperated by comma)</small></label>
                                        <textarea rows="4" class="form-control" name="g_languages"><?= $entry['g_languages'] ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Is Active &nbsp;</label><br>
                                        <div class="make-switch switch-mini" data-on-label="Yes" data-off-label="No">
                                            <input type="checkbox" checked="true" name="group_active" <?php if ($entry['active']) { echo 'checked="checked"'; } ?>>
                                        </div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                                <br>
                                <div class="col-md-12">
                                    <?php 
                                    $days = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
                                    $timeOfDays = 
                                    array(
                                        array("display" =>"1:00 am", "value" =>"01:00:00"),
                                        array("display" =>"2:00 am", "value" =>"02:00:00"),
                                        array("display" =>"3:00 am", "value" =>"03:00:00"),
                                        array("display" =>"4:00 am", "value" =>"04:00:00"),
                                        array("display" =>"5:00 am", "value" =>"05:00:00"),
                                        array("display" =>"6:00 am", "value" =>"06:00:00"),
                                        array("display" =>"7:00 am", "value" =>"07:00:00"),
                                        array("display" =>"8:00 am", "value" =>"08:00:00"),
                                        array("display" =>"9:00 am", "value" =>"09:00:00"),
                                        array("display" =>"10:00 am", "value" =>"10:00:00"),
                                        array("display" =>"11:00 am", "value" =>"11:00:00"),
                                        array("display" =>"12:00 pm", "value" =>"12:00:00"),
                                        array("display" =>"1:00 pm", "value" =>"13:00:00"),
                                        array("display" =>"2:00 pm", "value" =>"14:00:00"),
                                        array("display" =>"3:00 pm", "value" =>"15:00:00"),
                                        array("display" =>"4:00 pm", "value" =>"16:00:00"),
                                        array("display" =>"5:00 pm", "value" =>"17:00:00"),
                                        array("display" =>"6:00 pm", "value" =>"18:00:00"),
                                        array("display" =>"7:00 pm", "value" =>"19:00:00"),
                                        array("display" =>"8:00 pm", "value" =>"20:00:00"),
                                        array("display" =>"9:00 pm", "value" =>"21:00:00"),
                                        array("display" =>"10:00 pm", "value" =>"22:00:00"),
                                        array("display" =>"11:00 pm", "value" =>"23:00:00"),
                                        // array("display" =>"12:00 am", "value" =>"00:00:00"),
                                    );
                                    ?>
                                    <strong>Opening days and hours</strong>     
                                    <br>                                   
                                    <br>          
                                    <?php $businessHours = $entry['business_hours']; ?>                  
                                    <div class="form-group">
                                        <?php foreach ($days as $key=>$day) { ?>
                                            <div class="row">
                                                <div class="col-xs-4 col-sm-4 col-lg-2 text-right">
                                                    <label class="control-label"><?= $day ?></label>
                                                </div>
                                                <div class="col-xs-8 col-sm-8 col-lg-10">
                                                    <select name="opening_time_<?= $key ?>" id="opening_time_<?= $key ?>">
                                                        <option value="">Opening Hours</option>
                                                        <?php foreach ($timeOfDays as $timeOfDay) { ?>
                                                            <option value="<?= $timeOfDay['value'] ?>"><?= $timeOfDay['display'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    &nbsp;&nbsp;-&nbsp;&nbsp;
                                                    <select name="closing_time_<?= $key ?>" id="closing_time_<?= $key ?>">
                                                        <option value="">Closing Hour</option>
                                                        <?php foreach ($timeOfDays as $timeOfDay) { ?>
                                                            <option value="<?= $timeOfDay['value'] ?>"><?= $timeOfDay['display'] ?></option>
                                                        <?php } ?>
                                                    </select>                                             
                                                </div>
                                            </div>
                                            <script>
                                                <?php
                                                if($entry['business_hours'][$key]['start_time'] == "00:00:00")
                                                    $start_time = '';
                                                else
                                                    $start_time = $entry['business_hours'][$key]['start_time'];
                                                if($entry['business_hours'][$key]['end_time'] == "00:00:00")
                                                    $end_time = '';
                                                else
                                                    $end_time = $entry['business_hours'][$key]['end_time'];
                                                ?>
                                                var selectOpeningTime= $('#opening_time_<?= $key ?>');
                                                var openingTime = '<?= $start_time ?>';
                                                selectOpeningTime.val(openingTime);

                                                var selectClosingTime= $('#closing_time_<?= $key ?>');
                                                var closingTime = '<?= $end_time ?>';
                                                selectClosingTime.val(closingTime);
                                            </script> 
                                        <?php } ?>                                         
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                                <br>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="hidden" name="old_group_image" value="<?= $entry['g_icon'] ?>">
                                        <label class="col-sm-4 control-label" style="padding-left: 0;">Group Icon</label>
                                        <div class="col-sm-8">

                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail"
                                                     style="width: 50px; height: 50px;"
                                                     data-trigger="fileinput">
                                                    <?php if($entry['g_icon']) { ?>
                                                    <img src="<?= GROUPS_IMGS ?><?= $entry['g_icon'] ?>">
                                                    <?php } else { ?>
                                                    <img src="http://placehold.it/200x150" alt="...">
                                                    <?php } ?>
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail"
                                                     style="max-width: 50px; max-height: 50px"></div>
                                                <div>
                                                <span class="btn btn-white btn-file">
                                                    <span class="fileinput-new">Select image</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="group_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-orange fileinput-exists"
                                                       data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                           <div class="panel-options">
                               <button type="submit" class="btn btn-success">Submit</button>
                               <a href="<?= ADMIN_PAGES ?>groups/" class="btn btn-default">Back to All</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../common/footer.php" ?>

</div>
</div>

<?php include "../common/foot.php" ?>

<script src="<?= ADMIN_JS ?>jquery.validate.min.js"></script>
<script src="<?= ADMIN_JS ?>fileinput.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-switch.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-datepicker.js"></script>

</body>
</html>