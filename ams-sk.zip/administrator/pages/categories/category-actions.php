<?php
require "../../config/configuration.php";

define('TABLE_NAME', 'categories');
define('LABEL_SINGLE', 'Category');
define('LABEL_PLURAL', 'Categories');
define('TABLE_PRIMARY_KEY', 'c_id');
define('ROOT_PATH', 'pages/categories');

if (isset($_POST['action']) && $_POST['action'] == "add") {

    var_dump($_FILES);
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'cat_image', DIR_CATEGORIES, false);

    if($isUploaded) {
        $_POST['cat_image'] = $isUploaded;
    } else {
        $_POST['cat_image'] = '';
    }

    // inserting new
    $inserted = addCategory($_POST);

    // Set response
    if($inserted) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully added a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while adding a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == "edit") {
    // Upload profile image
    $isUploaded = uploadFile($_FILES, 'cat_image', DIR_CATEGORIES, $_POST['old_cat_image']);

    if($isUploaded) {
        $_POST['cat_image'] = $isUploaded;
    } else {
        $_POST['cat_image'] = $_POST['old_cat_image'];
    }

    // updating new
    $updated = modifyCategory($_POST, $_POST['id']);

    // Set response
    if($updated) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully updated a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while updating a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_GET['action']) && $_GET['action'] == "delete") {
    // delete
    $deleted = deleteQuery($_GET['id'], TABLE_NAME, TABLE_PRIMARY_KEY);

    // Set response
    if($deleted) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully deleted a ' . LABEL_SINGLE . '.');
    } else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while deleting a ' . LABEL_SINGLE . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
} elseif (isset($_POST['action']) && $_POST['action'] == 'delete-selected') {
    // Get player Ids from POST
    $deleteIds = explode(',', $_POST['inputDeleteIds']);

    $response = true;
    $response = deleteQueryForIds($_POST['inputDeleteIds'], TABLE_NAME, TABLE_PRIMARY_KEY);

    // Set response
    if($response) {
        makeSessionResponse('success', LABEL_PLURAL, 'You have successfully deleted selected ' . LABEL_PLURAL . '.');
    }else {
        makeSessionResponse('error', LABEL_PLURAL, 'You have an error while deleting selected ' . LABEL_PLURAL . '.');
    }

    $redirect_url = SITEURL_ADMIN . ROOT_PATH;
    redirect($redirect_url);
}
elseif(isset($_GET['search_keyword']) && $_GET['action'] == "search") {

    $data =searchDataBykeyword(TABLE_NAME, 'c_name',$_GET['search_keyword']);
    $ajaxResponse['htmlData'] = getSearchValueTabularCategories($data);
    echo json_encode($ajaxResponse);
}

