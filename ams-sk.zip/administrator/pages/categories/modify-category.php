<?php require "../../config/configuration.php"; ?>

<?php
if (!isLogin()) {
    redirect(SITEURL_ADMIN . 'index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../common/head.php" ?>
</head>
<body class="page-body">

<div class="page-container">
    <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <?php include "../common/sidebar.php" ?>

    </div>
    <div class="main-content">

        <?php if (isset($_GET['id'])) { ?>
            <?php $pageName = "Modify Category"; ?>
        <?php } else { ?>
            <?php $pageName = "Add a Category"; ?>
        <?php } ?>

        <?php include "../common/topbar.php" ?>

        <hr/>

        <div class="row">
            <div class="col-md-12">

                <?php $entry = getCategory($_GET['id']); ?>

                <form role="form" id="form1" method="post" action="category-actions.php" class="validate" enctype="multipart/form-data">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="panel-title">Category Information</div>

                            <div class="panel-options">
                                <div style="margin-top: 4px;">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="<?= ADMIN_PAGES ?>categories/" class="btn btn-default">Back to All</a>
                                </div>
                            </div>
                        </div>

                        <div class="panel-body">
                            <?php if (isset($_GET['id'])) { ?>
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                            <?php } else { ?>
                                <input type="hidden" name="action" value="add">
                            <?php } ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label">Category Name</label>

                                                <input type="text" class="form-control" name="c_name"
                                                       data-validate="required"
                                                       value="<?= $entry['c_name'] ?>"
                                                       placeholder="Enter your category name"/>

                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label">Category Parent</label>
                                                <select class="form-control" name="parent_id" id="cParent">
                                                    <option value="0" selected>Select parent Category</option>
                                                    <?php 
                                                    $categories = getAllCategories(false, 'all');
                                                    foreach ($categories as $key => $entrySelect) { ?>
                                                        <?php if (isset($_GET['id']) && $entrySelect['c_id'] == $_GET['id']) { ?>
                                                            <!-- Do Nothing -->
                                                        <?php } else { ?>
                                                            <option value="<?= $entrySelect['c_id']; ?>"><?= $entrySelect['c_name']; ?></option>
                                                        <?php } ?>                                                
                                                    <?php } ?>
                                                </select>
                                                <script>
                                                    var selectCParent= $('#cParent');
                                                    var cParent = '<?= $entrySelect['parent_id'] ?>';
                                                    selectCParent.val(cParent);
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                     <div class="form-group">
                                        <label class="control-label">Category Description</label>
                                        <textarea rows="5" class="form-control" name="c_desc"><?= $entry['c_desc'] ?></textarea>
                                    </div>
                                 </div>   
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Category Order</label>
                                        <input type="text" class="form-control" name="c_order"
                                               value="<?= $entry['c_order'] ? $entry['c_order'] : 0 ?>"
                                               placeholder="Enter a number (Represents order in the list)" />
                                    </div>
                                </div>   
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Is Active &nbsp;</label><br>
                                        <div class="make-switch switch-mini" data-on-label="Yes" data-off-label="No">
                                            <input type="checkbox" checked="true" name="category_active" <?php if ($entry['active']) { echo 'checked="checked"'; } ?>>
                                        </div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                                <br>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="hidden" name="old_cat_image" value="<?= $entry['c_icon'] ?>">
                                        <label class="col-sm-4 control-label" style="padding-left: 0;">Category Icon</label>
                                        <div class="col-sm-8">

                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail"
                                                     style="width: 50px; height: 50px;"
                                                     data-trigger="fileinput">
                                                    <?php if($entry['c_icon']) { ?>
                                                    <img src="<?= CATEGORIES_IMGS ?><?= $entry['c_icon'] ?>">
                                                    <?php } else { ?>
                                                    <img src="http://placehold.it/200x150" alt="...">
                                                    <?php } ?>
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail"
                                                     style="max-width: 50px; max-height: 50px"></div>
                                                <div>
                                                <span class="btn btn-white btn-file">
                                                    <span class="fileinput-new">Select image</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="cat_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-orange fileinput-exists"
                                                       data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                           <div class="panel-options">
                               <button type="submit" class="btn btn-success">Submit</button>
                               <a href="<?= ADMIN_PAGES ?>categories/" class="btn btn-default">Back to All</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../common/footer.php" ?>

</div>
</div>

<?php include "../common/foot.php" ?>

<script src="<?= ADMIN_JS ?>jquery.validate.min.js"></script>
<script src="<?= ADMIN_JS ?>fileinput.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-switch.min.js"></script>
<script src="<?= ADMIN_JS ?>bootstrap-datepicker.js"></script>

</body>
</html>