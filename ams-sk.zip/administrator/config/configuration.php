<?php
ob_start();
error_reporting(1);
session_start();

ini_set("date.timezone", "Asia/Karachi");
date_default_timezone_set("Asia/Karachi");

//DATABASE SETTINGS
$config['host'] 		= 'localhost';
$config['user'] 		= 'root';
$config['pass'] 		= '';
$config['dbname']	 	= 'sk_ams';

$pdo = '';

try {
    $pdo = new PDO("mysql:host=".$config['host'].";dbname=".$config['dbname'], $config['user'], $config['pass']);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
    exit();
}

//HTTP REGUEST URLS FOR CSS, IMAGES AND JS
define('SITEURL', "http://".$_SERVER['SERVER_NAME']."/");
define('SOURCEROOT', $_SERVER['DOCUMENT_ROOT'].'/');
define('DIR_CATEGORIES', SOURCEROOT.'content/categories/');
define('CATEGORIES_IMGS', SITEURL.'content/categories/');
define('DIR_GROUPS', SOURCEROOT.'content/groups/');
define('GROUPS_IMGS', SITEURL.'content/groups/');
define('DIR_IMGS', SOURCEROOT.'resources/images/');
define('DIR_USERS_IMGS', SOURCEROOT.'resources/images/users/');
define('USER_IMAGES', SITEURL.'resources/images/users/');
define('DIR_FLAGS_IMGS', SOURCEROOT.'resources/images/country_flags/');
define('COUNTRY_FLAGS_IMAGES', SITEURL.'resources/images/country_flags/');
define('DIR_KIT_IMGS', SOURCEROOT.'resources/images/country_kit/');
define('COUNTRY_KIT_IMAGES', SITEURL.'resources/images/country_kit/');

// For Admin
define('SOURCEROOT_ADMIN', $_SERVER['DOCUMENT_ROOT'].'/administrator/');
define('SITEURL_ADMIN', SITEURL.'administrator/');
define('ADMIN_IMAGES', SITEURL_ADMIN.'resources/images/');
define('ADMIN_IMGS', SITEURL_ADMIN.'resources/imgs/');
define('ADMIN_CSS', SITEURL_ADMIN.'resources/css/');
define('ADMIN_JS', SITEURL_ADMIN.'resources/js/');
define('ADMIN_PAGES', SITEURL_ADMIN.'pages/');

define ('PER_PAGE', 20);

// Call Functions for the site
require SOURCEROOT_ADMIN . "actions/functions.php";

$admin_secure_pin = "6b5a4694078bab7c9ac2853d31b52d7b";

//$admin_secure_pin = "a369fec2f4b170fa7d38da681f169939";  //Areej@Khan321
$site_access="fcp_sevenkoncepts";
$site_access_pass=md5("manager");